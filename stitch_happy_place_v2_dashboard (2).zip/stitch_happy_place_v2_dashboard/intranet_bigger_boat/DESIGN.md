---
name: Intranet Bigger Boat
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#514443'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#837373'
  outline-variant: '#d5c2c1'
  surface-tint: '#7e5353'
  primary: '#7e5353'
  on-primary: '#ffffff'
  primary-container: '#c99695'
  on-primary-container: '#532f2f'
  inverse-primary: '#f0b9b8'
  secondary: '#5e5e63'
  on-secondary: '#ffffff'
  secondary-container: '#e4e1e8'
  on-secondary-container: '#646469'
  tertiary: '#715a4a'
  on-tertiary: '#ffffff'
  tertiary-container: '#ba9d8b'
  on-tertiary-container: '#493527'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#f0b9b8'
  on-primary-fixed: '#311213'
  on-primary-fixed-variant: '#633c3c'
  secondary-fixed: '#e4e1e8'
  secondary-fixed-dim: '#c8c5cc'
  on-secondary-fixed: '#1b1b20'
  on-secondary-fixed-variant: '#47464c'
  tertiary-fixed: '#fddcc8'
  tertiary-fixed-dim: '#e0c0ad'
  on-tertiary-fixed: '#28180c'
  on-tertiary-fixed-variant: '#584233'
  background: '#faf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e3e2df'
typography:
  display:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: '0'
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  title-md:
    fontFamily: Bodoni Moda
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-regular:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-bold:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-caps-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  caption:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

Le design system repose sur une esthétique architecturale, éditoriale et rigoureusement orthogonaliste. Conçu pour l'intranet Bigger Boat, il allie la noblesse typographique de la haute couture à la rigueur structurelle d'une grille technique d'ingénierie. 

### Mouvements et principes directeurs
- **Minimalisme architectural :** Absence totale de fioritures plastiques, de dégradés et d'ombres portées. La hiérarchie naît uniquement du contraste des pleins et des déliés, de la tension des espacements et de l'alignement millimétré.
- **Tonalité éditoriale haut de gamme :** Le contraste entre la majesté classique de la Bodoni Moda et l'efficacité brute de la Space Grotesk installe un environnement professionnel serein, net et autoritaire.
- **Rigueur fonctionnelle et sobriété :** Les éléments graphiques superflus et les emojis sont proscrits au profit de symboles SVG précis et d'une sémantique textuelle explicite.

## Colors

La palette chromatique est régie par des attributions strictes sans dérogation possible. Chaque couleur possède une fonction sémantique ou structurelle exclusive :

- **Fond d'application (Canvas) :** `#F5F4F1` (Écru naturel, absorbant la fatigue visuelle).
- **Surfaces et conteneurs (Cartes) :** `#FFFFFF` (Blanc pur, découpé à angle droit).
- **Texte primaire et encadrements structurants :** `#28282D` (Anthracite profond assurant un contraste supérieur à 10:1 sur fond écru et blanc).
- **Accent primaire (Rose Poudré) :** `#C99695` (Réservé rigoureusement à l'action « Publier » et à de rares repères décoratifs majeurs).
- **Teintes secondaires d'accent :** `#F5D5D4` et `#F8DDDC` (Surlignages légers, arrière-plans de badges neutres), complétées par la nuance pêche `#F0D0BC`.
- **Statuts d'alerte stricts :**
  - **Rejet, alerte et retard :** `#C2272D` (Réservé exclusivement aux états critiques).
  - **Validation :** `#298646` (Réservé exclusivement à l'état « Validée »).
- **Focus et accessibilité :** `#D9822B` (Bordure continue de 3px appliquée sans décalage pour l'accessibilité clavier).
- **Interdictions formelles :** Aucun bouton vert, brun ou bleu marine ne doit être introduit dans l'interface.

## Typography

La construction typographique orchestre un dialogue binaire entre l'expression éditoriale classique et l'instrumentation technique :

- **Titres (Bodoni Moda - 700) :** Portent l'autorité et le raffinement architectural. Leur fort contraste plein/délié exige des interlignages nets et un calibrage strict pour éviter toute surcharge visuelle.
- **Corps de texte (Space Grotesk - 14px / interligne 20px) :** Garantit une lisibilité technique irréprochable et géométrique dans les blocs documentaires, les flux de données et les tableaux.
- **Libellés fonctionnels, boutons et onglets (Space Grotesk - 700 en MAJUSCULES) :** Fixés systématiquement entre 12px et 13px avec un espacement interlettrage positif (`0.08em` à `0.1em`). Ce traitement confère aux contrôles interactifs la précision d'un panneau de commande d'instrumentation navale.
- **Règle absolue d'accessibilité :** Aucun texte ne descend sous le seuil critique de 12px.

## Layout & Spacing

Le gabarit s'articule autour d'une grille modulaire stricte de 12 colonnes avec alignement au pixel près :

- **Écrans de bureau (Desktop >= 1024px) :** Grille fluide de 12 colonnes, marges extérieures fermes de `2.5rem` (40px) et gouttières de `1.5rem` (24px).
- **Tablettes (768px - 1023px) :** Grille de 8 colonnes, marges de `1.5rem` (24px), gouttières de `1rem` (16px).
- **Mobiles (< 768px) :** Grille de 4 colonnes, gouttières et marges calées à `1rem` (16px).
- **Rythme vertical :** Cadencé par des incréments fixes de 4px et 8px. Les sections de l'intranet s'assemblent comme des blocs appareillés d'une maçonnerie géométrique : pas de décalages arbitraires ni de marges flottantes.

## Elevation & Depth

Le design system rejette catégoriquement le mimétisme de profondeur par ombrage :

- **Ombres portées :** Rigoureusement interdites (`box-shadow: none` sur l'intégralité des composants).
- **Dégradés :** Strictement interdits (`background-image: none`).
- **Superposition et contraste de plan :** La profondeur s'exprime uniquement par la juxtaposition de plans monochromes et nets :
  - Niveau 0 : Fond d'application écru `#F5F4F1`.
  - Niveau 1 : Cartes et modules blancs `#FFFFFF`, bordés d'un filet unitaire de 1px plein `#28282D` ou séparés par des marges pleines.
  - Niveau 2 (Modales et panneaux coulissants) : Fond blanc `#FFFFFF`, encadrement d'un filet plein de 2px anthracite `#28282D`, posé sur un calque d'occlusion (backdrop) écru opacifié ou noir plat sans flou (aucun `backdrop-filter`).

## Shapes

La géométrie du système est intransigeante :

- **Rayon de courbure :** 0px (`border-radius: 0px` absolu).
- **Aucune exception :** Boutons, cartes, champs d'entrée, pastilles de statut, onglets et fenêtres modales présentent des angles vifs et droits à 90 degrés.
- **Formes capsules et arrondis :** Formellement prohibés sur l'ensemble de l'intranet.

## Components

Tous les composants interactifs respectent une hauteur minimale de 44px afin de garantir la conformité ergonomique et l'accessibilité tactile.

### Boutons
- **Bouton Principal :** Fond anthracite `#28282D`, texte blanc en Space Grotesk 700 MAJUSCULES (12px–13px), hauteur minimale de 44px, padding horizontal de 24px, bordure nulle, `border-radius: 0`.
- **Bouton Publier (Exclusif) :** Fond rose poudré `#C99695`, texte anthracite `#28282D` en Space Grotesk 700 MAJUSCULES. Réservé à l'action terminale de publication.
- **Bouton Secondaire :** Fond transparent, bordure de 1px pleine `#28282D`, texte anthracite `#28282D`.
- **Focus d'accessibilité (Tous boutons) :** Contour extérieur net de 3px solide `#D9822B` sans arrondi.
- **Interdictions formelles :** Aucun bouton vert, brun ni bleu marine.

### Boutons Radio & Cases à cocher
- **Géométrie :** Carrés parfaits à angles droits (y compris pour les radios, différenciés graphiquement par un motif interne carré plein ou réticule géométrique).
- **Dimensions :** Zone d'impact minimale 44x44px ; marqueur visible de 18x18px délimité par une bordure 1px anthracite `#28282D`.
- **État actif :** Remplissage intérieur anthracite `#28282D` avec coche géométrique blanche (SVG).

### Champs de saisie (Inputs)
- **Structure :** Hauteur de 44px, fond blanc `#FFFFFF`, bordure de 1px pleine `#28282D`, `border-radius: 0`.
- **Typographie interne :** Space Grotesk 14px, texte anthracite `#28282D`.
- **Focus :** Remplacement de la bordure par un contour net de 3px solide `#D9822B`.

### Cartes (Cards)
- **Structure :** Fond blanc `#FFFFFF`, `border-radius: 0`, sans ombre (`box-shadow: none`).
- **Encadrement :** Bordure pleine de 1px anthracite `#28282D` ou juxtaposition directe sur le fond écru `#F5F4F1`.
- **Disposition intérieure :** Marges internes calées sur `space-lg` (24px).

### Badges et indicateurs d'état (Double Encodage Obligatoire)
- **Principe d'accessibilité :** L'information ne doit jamais reposer uniquement sur la couleur. Chaque statut associe obligatoirement un libellé textuel explicite en Space Grotesk 700 MAJUSCULES et un glyphe SVG géométrique dédié.
- **Pastilles capsules bannies :** Les indicateurs sont des rectangles droits rigides (`border-radius: 0px`).
- **Statut « Validée » :** Bordure et texte vert `#298646`, fond blanc ou vert teinté très clair, précédé de l'icône SVG `[✔]`.
- **Statuts « Alerte », « Refus » et « Retard » :** Bordure et texte rouge `#C2272D`, fond blanc, précédé de l'icône SVG `[▲]` ou `[✖]`.
- **Statut neutre / en attente :** Fond `#F5D5D4` ou `#F0D0BC`, texte `#28282D`, précédé de l'icône SVG `[■]`.

### Onglets (Tabs)
- **Forme :** Rectangles découpés à angle droit, hauteur de 44px.
- **Actif :** Fond `#28282D`, texte blanc Space Grotesk 700 MAJUSCULES.
- **Inactif :** Fond écru `#F5F4F1` ou blanc `#FFFFFF`, texte `#28282D`, séparé par une bordure de 1px droite.