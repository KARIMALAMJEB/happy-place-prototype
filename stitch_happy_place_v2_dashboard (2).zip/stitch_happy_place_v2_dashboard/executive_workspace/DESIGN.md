---
name: Executive Workspace
colors:
  surface: '#f9f9fc'
  surface-dim: '#d9dadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#45474a'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#75777b'
  outline-variant: '#c5c6ca'
  surface-tint: '#5c5e63'
  primary: '#171a1e'
  on-primary: '#ffffff'
  primary-container: '#2c2f33'
  on-primary-container: '#94969b'
  inverse-primary: '#c4c6cb'
  secondary: '#98434e'
  on-secondary: '#ffffff'
  secondary-container: '#fe959f'
  on-secondary-container: '#782b36'
  tertiary: '#1b1a14'
  on-tertiary: '#ffffff'
  tertiary-container: '#312f28'
  on-tertiary-container: '#9a968d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e2e7'
  primary-fixed-dim: '#c4c6cb'
  on-primary-fixed: '#191c20'
  on-primary-fixed-variant: '#44474b'
  secondary-fixed: '#ffdadb'
  secondary-fixed-dim: '#ffb2b8'
  on-secondary-fixed: '#40010f'
  on-secondary-fixed-variant: '#7a2c37'
  tertiary-fixed: '#e7e2d8'
  tertiary-fixed-dim: '#cac6bd'
  on-tertiary-fixed: '#1d1c16'
  on-tertiary-fixed-variant: '#494740'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.375rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Work Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-md:
    fontFamily: Work Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Work Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.005em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  code-sm:
    fontFamily: Work Sans
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an architectural, editorial workspace engineered for recruitment leadership, talent partners, and executive operators. Drawing direct inspiration from document-first editorial workspaces, it prioritizes typographical hierarchy, information density, and tactile paper-like warmth over decorative chrome.

### Personality & Demeanor
- **Architectural & Deliberate:** Clear structural lines, strict content boundaries, and quiet surfaces that eliminate visual noise during high-throughput talent pipeline management.
- **Warm & Authoritative:** Replaces sterile, blue-shifted software grays with warm ecru canvas tones and deep charcoal inks, producing an inviting yet rigorous executive aesthetic.
- **Restrained Precision:** Color functions as data and status syntax rather than decoration. Accents appear only to denote state transitions, priority markers, or active focal points.

### Design Movement
The visual style is **Warm Corporate Minimalism with Structural Lines**. It relies on 1px crisp borders, subtle shifts between tonal ecru containers, and sharp grotesque typography to frame high-density recruitment metrics, candidate profiles, and placement pipelines.

## Colors

The palette reproduces an editorial substrate. Canvas layers transition across calibrated ecru tones, while foreground typography anchors on deep charcoal to maintain strict WCAG 2.2 AA contrast standards (minimum 4.5:1 for body copy; exceeding 10:1 on default canvases).

### Surface Architecture
- **Canvas Base (`#FBF9F5`):** The primary view layer representing raw paper. Used for top-level app frames and background regions.
- **Surface Muted (`#F4F1EA`):** Secondary nested workspace layer for sidebars, table headers, and grouped panels.
- **Surface Elevated (`#EDE8DE`):** Tertiary interactive layer for active card states, popovers, and selected table rows.
- **Surface Inset (`#FFFFFF`):** High-contrast crisp white reserved exclusively for data entry inputs and active document reading sheets.

### Ink & Structure
- **Ink Primary (`#1E2022`):** Pure charcoal for headlines, primary figures, and critical data points (contrast ratio ~14.2:1 against canvas).
- **Ink Secondary (`#2C2F33`):** Neutral dark slate for standard body typography, interactive labels, and primary buttons.
- **Ink Muted (`#4B4F54`):** Supporting metadata, timestamps, helper descriptions, and secondary icons (contrast ratio ~6.5:1).
- **Border Structural (`#E2DDD5`):** Structural 1px boundary line separating table cells, card containers, and pane partitions.
- **Border Subtle (`#ECE7DF`):** Internal horizontal dividers and secondary row separators.

### Operational Accents & Status Tints
- **Accent Rose Primary (`#B85D67`):** Focused semantic highlights, urgent placement notifications, and active workspace badges.
- **Accent Rose Surface (`#F7EBEB`):** Background fill for high-priority status badges and active navigation indicators.
- **Accent Rose Border (`#D89A9E`):** Boundary line for critical alert states and active selection rings.

## Typography

The typographic hierarchy pairs **Hanken Grotesk** for structural, authoritative headlines and interactive labels with **Work Sans** for legible, neutral body text and dense candidate pipelines.

### Principles
- **Editorial Proportions:** Headline levels feature tight negative tracking (`-0.01em` to `-0.025em`) to emphasize clean architectural forms across executive cockpits.
- **Tabular Alignment:** When rendering candidate metrics, salary ranges, and pipeline counts, apply `font-feature-settings: "tnum" 1` to prevent horizontal jitter during live filtering.
- **Label Micro-Typing:** Labels at `label-sm` use all-caps with generous positive letter spacing (`0.04em`) to establish visual separation for status badges, table headers, and category tags without added background heaviness.

## Layout & Spacing

The layout is built around a structured 12-column grid system paired with strict 4px/8px incremental component rhythm. Density is calibrated for professional desktop cockpits while scaling fluidly to mobile inspection sheets.

### Layout Model
- **Executive Shell (Desktop):** A fixed 240px utility sidebar on the left, flanked by a fluid 12-column workspace spanning margins of `margin-lg` (`2.5rem`) and column gutters of `gutter-lg` (`1.5rem`).
- **Data Densities:** Table row heights strictly adhere to 36px (compact) or 48px (standard), allowing talent operators to review 20+ applicant dossiers above the fold without page scrolling.
- **Reflow Rules:**
  - **Desktop (≥ 1280px):** 12 columns. Dual-pane inspection views (pipeline list on left, candidate sheet pinned on right).
  - **Tablet (768px – 1279px):** 8 columns. Sidebar folds into a slide-over drawer; secondary candidate panels collapse into full-width modal sheets. Margin reduces to `margin` (`1.5rem`).
  - **Mobile (< 768px):** 4 columns. Gutter shrinks to `gutter` (`1rem`), and margins normalize to `1rem`. All multi-column cards stack vertically.

## Elevation & Depth

Visual separation relies on **structural borders and tonal paper stacking** rather than heavy drop shadows. This preserves the Notion-inspired, document-first tactile feeling.

### Depth Hierarchy
- **Level 0 (Base Canvas):** `#FBF9F5` — Root background layer. Borderless.
- **Level 1 (Structural Containers):** `#F4F1EA` or `#FFFFFF` — Bounded by a crisp 1px solid border (`#E2DDD5`). Flat elevation, no drop shadow.
- **Level 2 (Interactive Floating Elements):** Dropdown menus, role-switchers, and filter popovers sit on `#FFFFFF` with a 1px border (`#E2DDD5`) and an ambient, ultra-diffused shadow: `0 4px 16px -2px rgba(30, 32, 34, 0.06), 0 2px 4px -1px rgba(30, 32, 34, 0.03)`.
- **Level 3 (Modal Sheets & Cockpit Overlays):** `#FFFFFF` surface enclosed by `#E2DDD5` with a dedicated veil: backdrop blur of 2px overlaid on `rgba(30, 32, 34, 0.25)`. Elevation shadow: `0 12px 32px -4px rgba(30, 32, 34, 0.12)`.

## Shapes

The shape system employs **Soft (`1`)** geometry. Radii are understated and deliberate, avoiding casual pill geometries while softening severe right angles.

### Curvature Tokens
- **Base Components (`rounded-sm` / `0.25rem`):** Buttons, text inputs, table cell selections, and compact badges.
- **Panels & Cards (`rounded-md` / `0.375rem`):** Cockpit metric cards, candidate overview modules, and floating popovers.
- **Modals & Drawers (`rounded-lg` / `0.5rem`):** Executive dossier slide-overs and full confirmation dialogs.
- **Pills (`rounded-full` / `9999px`):** Restricted solely to status indicator dots and high-visibility live indicator capsules.

## Components

### Buttons
- **Primary:** Background `#2C2F33`, text `#FBF9F5`, border 1px solid `#1E2022`. Hover: `#1E2022`. Active: `#141517`. Focus: 2px offset outline `#B85D67`. Height: 32px (compact) or 38px (regular). Padding: `0.5rem 0.875rem`. Border radius: `0.25rem`.
- **Secondary:** Background `#FFFFFF`, text `#2C2F33`, border 1px solid `#E2DDD5`. Hover: `#F4F1EA` with border `#D89A9E`.
- **Tertiary / Ghost:** Background transparent, text `#4B4F54`. Hover: `#EDE8DE`, text `#1E2022`.

### Status Pills & Badges
- **Rose Accent (Urgent / Active / Top Match):** Background `#F7EBEB`, text `#B85D67`, border 1px solid `#D89A9E`.
- **Neutral (Screening / Queued):** Background `#F4F1EA`, text `#4B4F54`, border 1px solid `#E2DDD5`.
- **Dimensions:** Font size `0.6875rem` (`label-sm`), font weight `600`, padding `0.125rem 0.5rem`, border radius `0.25rem`. Letter-spacing `0.04em`.

### Role-Switcher Chips
- Horizontal group of segmented controls bounded in an outer `#EDE8DE` frame with 1px border `#E2DDD5`.
- **Selected Chip:** Background `#FFFFFF`, text `#1E2022`, border 1px solid `#E2DDD5`, soft ambient shadow `0 1px 2px rgba(30, 32, 34, 0.04)`.
- **Unselected Chip:** Background transparent, text `#4B4F54`. Hover: text `#1E2022`.

### Cards & Modular Containers
- Background `#FFFFFF` or `#F4F1EA`.
- 1px solid boundary line `#E2DDD5`. No drop shadow in resting state.
- Card headers feature an internal border-bottom divider (`#ECE7DF`) with uppercase `label-sm` titles and subtle micro-guidance subtitles.

### Form Inputs
- Background `#FFFFFF`, text `#1E2022`, border 1px solid `#E2DDD5`.
- Height: 36px. Internal padding: `0.375rem 0.625rem`. Border radius: `0.25rem`. Font size: `0.875rem`.
- **Focus State:** Border color `#B85D67` with a 1px solid glow ring `rgba(184, 93, 103, 0.2)`. Placeholder text: `#8C8E91`.

### Lists & Data Grids
- **Header Cells:** Background `#F4F1EA`, border-bottom 1px solid `#E2DDD5`, text `label-sm` (`#4B4F54`), padding `0.5rem 0.75rem`.
- **Body Rows:** Border-bottom 1px solid `#ECE7DF`. Hover: `#FBF9F5`. Selected: `#F7EBEB` with an inset 2px left border `#B85D67`.